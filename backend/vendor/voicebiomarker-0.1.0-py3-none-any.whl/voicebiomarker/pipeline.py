"""The shared path from decoded Clips to scores. eval/ training and the service both use these functions,
so the features a model is trained on are computed exactly as they are at serving time."""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from . import audio
from .config import (CLIPPING_MAX_FRACTION, MIN_SNR_DB, MIN_VOWEL_NET_S, TASKS, VOWEL_TASKS,
                     PipelineConfig)
from .features import high_level, low_level
from .windows import disjoint_windows, split_window

# Rejection reasons (also the API's `reason` values)
REASON_CLIPPING = "clipping"
REASON_LOW_SNR = "low_snr"
REASON_VOWEL_TOO_SHORT = "vowel_too_short"
REASON_TOO_LITTLE_SPEECH = "too_little_speech"


@dataclass
class PreparedRecording:
    sr: int
    speech: dict[str, np.ndarray]  # speech-only samples per Task
    net_speech_s: float
    reason: str | None = None
    log_message: str = ""
    details: dict = field(default_factory=dict)


def prepare(decoded: dict[str, tuple[np.ndarray, float]], sr: int, config: PipelineConfig) -> PreparedRecording:
    """VAD each Clip and apply the quality gate. `decoded[task] = (samples, clipping_fraction)`."""
    speech = {t: audio.speech_only(decoded[t][0], sr) for t in TASKS}
    net = {t: speech[t].size / sr for t in TASKS}
    total = float(sum(net.values()))
    rec = PreparedRecording(sr=sr, speech=speech, net_speech_s=total, details={"net_speech_per_task_s": net})

    clipped = [t for t in TASKS if decoded[t][1] > CLIPPING_MAX_FRACTION]
    if clipped:
        rec.reason = REASON_CLIPPING
        rec.log_message = (f"audio clips (too loud) in {', '.join(clipped)}: move the mic further away "
                           f"or lower the input gain")
        return rec
    snr = audio.snr_db(np.concatenate([decoded[t][0] for t in TASKS]), sr)
    rec.details["snr_db"] = snr
    if snr < MIN_SNR_DB:
        rec.reason = REASON_LOW_SNR
        rec.log_message = f"background noise too high (speech-to-noise {snr:.1f} dB < {MIN_SNR_DB:.0f} dB)"
        return rec
    short = [t for t in VOWEL_TASKS if net[t] < MIN_VOWEL_NET_S]
    if short:
        rec.reason = REASON_VOWEL_TOO_SHORT
        rec.log_message = (f"vowel held too briefly in {', '.join(short)} "
                           f"(< {MIN_VOWEL_NET_S:.1f} s of voicing); hold each vowel for 5 s")
        return rec
    if total < config.min_net_speech_s:
        rec.reason = REASON_TOO_LITTLE_SPEECH
        rec.log_message = (f"only {total:.1f} s of speech found, need at least "
                           f"{config.min_net_speech_s:.0f} s (30 s recommended)")
        return rec
    rec.log_message = f"{total:.1f} s of speech"
    return rec


def _features(window: np.ndarray, sr: int, config: PipelineConfig) -> np.ndarray:
    M, _ = low_level(window, sr)
    return high_level(M, config.moments)


def window_features(rec: PreparedRecording, config: PipelineConfig) -> list[np.ndarray]:
    """High-level features for each Analysis window used for scoring (two if enough speech, else one)."""
    clips = [rec.speech[t] for t in TASKS]
    if rec.net_speech_s >= config.two_windows_min_s:
        two = disjoint_windows(clips, rec.sr, config.window_s)
        if two is not None:
            return [_features(w, rec.sr, config) for w in two]
    one = split_window(clips, rec.sr, config.window_s)
    if one is None:
        return []
    return [_features(one[0], rec.sr, config)]


def training_features(rec: PreparedRecording, config: PipelineConfig) -> dict[str, np.ndarray] | None:
    """For eval/: both moment readings on the split window (full, left half, right half), plus the two
    disjoint windows when available (for test-retest). Low-level series are computed once per window."""
    clips = [rec.speech[t] for t in TASKS]
    one = split_window(clips, rec.sr, config.window_s)
    if one is None:
        return None
    w, cut = one
    M, _ = low_level(w, rec.sr)
    k = int(cut / rec.sr * 100)
    out: dict[str, np.ndarray] = {}
    for mom, tag in (("distribution", "h1"), ("autocorr", "h2")):
        out[f"{tag}_full"] = high_level(M, mom)
        out[f"{tag}_left"] = high_level(M[:, :k], mom)
        out[f"{tag}_right"] = high_level(M[:, k:], mom)
    two = disjoint_windows(clips, rec.sr, config.window_s) if rec.net_speech_s >= config.two_windows_min_s else None
    for i, win in enumerate(two or []):
        Mw, _ = low_level(win, rec.sr)
        out[f"h1_win{i}"] = high_level(Mw, "distribution")
        out[f"h2_win{i}"] = high_level(Mw, "autocorr")
    return out
