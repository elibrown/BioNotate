"""Low-level series ("the image", spec section 2) and high-level moments (spec section 3)."""
from __future__ import annotations

import librosa
import numpy as np
import parselmouth
from parselmouth.praat import call

from .config import (FRAME_LENGTH_S, FRAMES_PER_SECOND, N_LOW_LEVEL, N_MEL_BANDS, N_MOMENTS,
                     PERTURBATION_HALF_WINDOW_S, PITCH_CEILING_HZ, PITCH_FLOOR_HZ)

LOW_LEVEL_NAMES: list[str] = (
    [f"mfcc{i}" for i in range(N_MEL_BANDS)]
    + [f"dmfcc{i}" for i in range(N_MEL_BANDS)]
    + ["f0", "voicing", "df0"]
    + [f"F{i}" for i in range(1, 5)] + [f"B{i}" for i in range(1, 5)]
    + ["jitter_local", "jitter_rap", "jitter_ppq5", "shimmer_local", "shimmer_apq3", "shimmer_apq5"]
    + ["intensity_db", "loudness", "hnr", "cpp", "spectral_tilt", "zcr"]
)
assert len(LOW_LEVEL_NAMES) == N_LOW_LEVEL

MOMENT_NAMES = {
    "distribution": ["mean", "var", "m3", "m4", "m5", "m6", "m7", "m8"],
    "autocorr": [f"lag{k}" for k in range(1, 9)],
}


def high_level_names(moments: str) -> list[str]:
    return [f"{s}.{m}" for s in LOW_LEVEL_NAMES for m in MOMENT_NAMES[moments]]


MFCC_MEAN_INDEX = np.array([i * N_MOMENTS for i in range(N_MEL_BANDS)])  # H1 "mean" of mfcc0..25


# --------------------------------------------------------------------------- low level

def _fit(x, n: int) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    return x[:n] if x.size >= n else np.concatenate([x, np.full(n - x.size, np.nan)])


def _perturbation(times, periods, amps, centers, half=PERTURBATION_HALF_WINDOW_S) -> np.ndarray:
    out = np.full((6, centers.size), np.nan)
    if times.size < 5:
        return out
    lo = np.searchsorted(times, centers - half)
    hi = np.searchsorted(times, centers + half)
    k5 = np.ones(5) / 5
    for k in range(centers.size):
        p, a = periods[lo[k]:hi[k]], amps[lo[k]:hi[k]]
        if p.size < 5:
            continue
        mp, ma = p.mean(), a.mean()
        if mp <= 0 or ma <= 0:
            continue
        out[0, k] = np.mean(np.abs(np.diff(p))) / mp
        out[1, k] = np.mean(np.abs(p[1:-1] - (p[:-2] + p[1:-1] + p[2:]) / 3)) / mp
        out[2, k] = np.mean(np.abs(p[2:-2] - np.convolve(p, k5, "valid"))) / mp
        out[3, k] = np.mean(np.abs(np.diff(a))) / ma
        out[4, k] = np.mean(np.abs(a[1:-1] - (a[:-2] + a[1:-1] + a[2:]) / 3)) / ma
        out[5, k] = np.mean(np.abs(a[2:-2] - np.convolve(a, k5, "valid"))) / ma
    return out


def _cpp_and_tilt(y: np.ndarray, sr: int, hop: int, n: int) -> tuple[np.ndarray, np.ndarray]:
    win = int(0.04096 * sr)  # Awan et al. CPP window, as in Murton 2017
    nfft = 1 << (win - 1).bit_length()
    S = np.abs(librosa.stft(y, n_fft=nfft, win_length=win, hop_length=hop, center=True))[:, :n] + 1e-10
    logS = 20 * np.log10(S)
    freqs_k = np.linspace(0, sr / 2, S.shape[0]) / 1000
    A = np.vstack([freqs_k, np.ones_like(freqs_k)]).T
    tilt = np.linalg.lstsq(A, logS, rcond=None)[0][0]
    ceps = np.fft.irfft(np.log(S ** 2), axis=0)[: nfft // 2]
    ceps_db = 10 * np.log10(ceps ** 2 + 1e-20)
    q = np.arange(nfft // 2) / sr
    rng = (q >= 1 / PITCH_CEILING_HZ) & (q <= 1 / PITCH_FLOOR_HZ)
    qr, seg = q[rng], ceps_db[rng]
    B = np.vstack([qr, np.ones_like(qr)]).T
    coef = np.linalg.lstsq(B, seg, rcond=None)[0]
    i = np.argmax(seg, axis=0)
    cols = np.arange(seg.shape[1])
    cpp = seg[i, cols] - (coef[0] * qr[i] + coef[1])
    return _fit(cpp, n), _fit(tilt, n)


def low_level(y: np.ndarray, sr: int) -> tuple[np.ndarray, np.ndarray]:
    """Return (75 x N matrix at 100 frames/s, voiced mask of length N)."""
    hop = sr // FRAMES_PER_SECOND
    win = int(FRAME_LENGTH_S * sr)
    nfft = 1 << (win - 1).bit_length()
    n = int(len(y) / sr * FRAMES_PER_SECOND)
    if n < 10:
        raise ValueError("audio too short for feature extraction")
    rows: list[np.ndarray] = []

    mf = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=N_MEL_BANDS, n_mels=N_MEL_BANDS, n_fft=nfft,
                              win_length=win, hop_length=hop, fmax=sr / 2)[:, :n]
    d = librosa.feature.delta(mf, width=5, mode="nearest") if mf.shape[1] >= 5 else np.zeros_like(mf)
    rows += [_fit(r, n) for r in mf] + [_fit(r, n) for r in d]

    snd = parselmouth.Sound(y.astype(np.float64), sampling_frequency=sr)
    pitch = snd.to_pitch_ac(time_step=1 / FRAMES_PER_SECOND, pitch_floor=PITCH_FLOOR_HZ,
                            pitch_ceiling=PITCH_CEILING_HZ)
    pa = pitch.selected_array
    grid = (np.arange(n) + 0.5) / FRAMES_PER_SECOND
    f0 = np.interp(grid, pitch.xs(), pa["frequency"], left=0, right=0)
    voiced = f0 > 0
    f0v = np.where(voiced, f0, np.nan)
    rows += [f0v, np.interp(grid, pitch.xs(), pa["strength"], left=0, right=0),
             np.concatenate([[np.nan], np.diff(f0v)])]

    fm = snd.to_formant_burg(time_step=1 / FRAMES_PER_SECOND, max_number_of_formants=5,
                             maximum_formant=min(5500.0, sr / 2 - 100))
    for getter in (fm.get_value_at_time, fm.get_bandwidth_at_time):
        for i in range(1, 5):
            vals = np.array([getter(i, t) for t in grid], dtype=float)
            rows.append(np.where(voiced, vals, np.nan))

    pp = call([snd, pitch], "To PointProcess (cc)")
    npts = call(pp, "Get number of points")
    pts = np.array([call(pp, "Get time from index", i + 1) for i in range(npts)])
    if pts.size > 6:
        periods = np.diff(pts)
        ok = (periods > 1 / PITCH_CEILING_HZ) & (periods < 1 / PITCH_FLOOR_HZ)
        a_idx = (pts[:-1] * sr).astype(int)
        b_idx = np.minimum((pts[1:] * sr).astype(int), len(y))
        amps = np.array([np.max(np.abs(y[a:b])) if b > a else np.nan for a, b in zip(a_idx, b_idx)])
        pert = _perturbation(pts[:-1][ok], periods[ok], amps[ok], grid)
    else:
        pert = np.full((6, n), np.nan)
    rows += list(pert)

    rms = librosa.feature.rms(y=y, frame_length=win, hop_length=hop)[0]
    rows.append(_fit(20 * np.log10(rms + 1e-10), n))
    P = np.abs(librosa.stft(y, n_fft=nfft, win_length=win, hop_length=hop)) ** 2
    pw = librosa.perceptual_weighting(P + 1e-12, librosa.fft_frequencies(sr=sr, n_fft=nfft))
    rows.append(_fit(librosa.db_to_power(pw).sum(0) ** 0.3, n))

    hnr = snd.to_harmonicity_cc(time_step=1 / FRAMES_PER_SECOND, minimum_pitch=PITCH_FLOOR_HZ)
    h = np.interp(grid, hnr.xs(), hnr.values[0], left=np.nan, right=np.nan)
    rows.append(np.where(voiced & (h > -199), h, np.nan))
    cpp, tilt = _cpp_and_tilt(y, sr, hop, n)
    rows += [np.where(voiced, cpp, np.nan), tilt]
    rows.append(_fit(librosa.feature.zero_crossing_rate(y, frame_length=win, hop_length=hop)[0], n))

    M = np.vstack(rows)
    assert M.shape[0] == N_LOW_LEVEL
    return M, voiced


# --------------------------------------------------------------------------- high level

def _distribution(x: np.ndarray) -> np.ndarray:
    x = x[np.isfinite(x)]
    if x.size < 20:
        return np.full(N_MOMENTS, np.nan)
    m, s = x.mean(), x.std()
    if s <= 0:
        return np.array([m, 0.0] + [np.nan] * 6)
    z = (x - m) / s
    return np.array([m, s * s] + [np.mean(z ** k) for k in range(3, 9)])


def _autocorr(x: np.ndarray) -> np.ndarray:
    x = x[np.isfinite(x)]
    if x.size < 20:
        return np.full(N_MOMENTS, np.nan)
    x = x - x.mean()
    v = float(np.dot(x, x))
    if v <= 0:
        return np.full(N_MOMENTS, np.nan)
    return np.array([np.dot(x[:-k], x[k:]) / v for k in range(1, 9)])


def high_level(M: np.ndarray, moments: str) -> np.ndarray:
    """600 high-level features: 8 moments of each of the 75 series."""
    fn = {"distribution": _distribution, "autocorr": _autocorr}[moments]
    return np.concatenate([fn(row) for row in M])
