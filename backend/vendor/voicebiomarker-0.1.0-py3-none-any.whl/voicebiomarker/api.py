"""Public entry point: analyse one Recording (five Task Clips)."""
from __future__ import annotations

from collections.abc import Mapping
from dataclasses import asdict, dataclass, field
from pathlib import Path

import numpy as np

from . import audio, model as model_mod, pipeline, voice_quality
from .config import COUNTING_TASKS, MAX_AUDIO_S, TASKS, VOWEL_TASKS

STATUS_OK = "ok"
STATUS_REJECTED = "rejected"


class RecordingTooLong(ValueError):
    """All Clips together exceed MAX_AUDIO_S (a request error, not a Rejection)."""


@dataclass(frozen=True)
class VoiceReading:
    status: str  # "ok" | "rejected"
    reason: str | None  # Rejection reason, None when ok
    log_message: str
    vocal_biomarker: float | None  # z-score vs. the Reference population
    quartile: int | None  # 1..4
    voice_quality: dict[str, float | None] = field(default_factory=dict)
    net_speech_s: float | None = None
    windows_used: int = 0
    model_version: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


_MODEL: model_mod.VocalModel | None = None


def _default_model() -> model_mod.VocalModel:
    global _MODEL
    if _MODEL is None:
        _MODEL = model_mod.load()
    return _MODEL


def analyze_clips(clips: Mapping[str, bytes | str | Path], _model: model_mod.VocalModel | None = None) -> VoiceReading:
    """Analyse one Recording.

    `clips` maps each Task name in `config.TASKS` to WAV/WebM/Opus bytes or a file path.
    Raises KeyError for a missing Task, audio.UndecodableAudio for unreadable audio and
    RecordingTooLong when the Clips exceed 120 s together. Everything else returns a VoiceReading.
    CPU-bound (several seconds); call it from a worker thread.
    """
    missing = [t for t in TASKS if t not in clips]
    if missing:
        raise KeyError(f"missing Task clip(s): {', '.join(missing)}")
    m = _model or _default_model()
    cfg, sr = m.config, m.config.sample_rate

    decoded = {}
    for t in TASKS:
        try:
            decoded[t] = audio.decode(clips[t], sr)
        except audio.UndecodableAudio as e:
            raise audio.UndecodableAudio(f"{t}: {e}") from e
    total_s = sum(y.size for y, _ in decoded.values()) / sr
    if total_s > MAX_AUDIO_S:
        raise RecordingTooLong(f"clips total {total_s:.0f} s, limit is {MAX_AUDIO_S:.0f} s")

    rec = pipeline.prepare(decoded, sr, cfg)
    net = round(rec.net_speech_s, 1)
    if rec.reason:
        return VoiceReading(STATUS_REJECTED, rec.reason, rec.log_message, None, None, {}, net, 0, m.version)

    feats = pipeline.window_features(rec, cfg)
    if not feats:
        return VoiceReading(STATUS_REJECTED, pipeline.REASON_TOO_LITTLE_SPEECH,
                            "not enough speech in every Task to build an Analysis window",
                            None, None, {}, net, 0, m.version)
    scores = [m.score(f) for f in feats]
    bio = float(np.mean(scores))
    vq = voice_quality.measure([rec.speech[t] for t in COUNTING_TASKS], [rec.speech[t] for t in VOWEL_TASKS], sr)
    msg = rec.log_message + (f"; biomarker averaged over {len(scores)} Analysis windows" if len(scores) > 1
                             else "; one Analysis window (send >= 30 s of speech for two)")
    return VoiceReading(STATUS_OK, None, msg, round(bio, 2), m.quartile(bio), vq, net, len(scores), m.version)
