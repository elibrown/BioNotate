"""The trained linear model and its standardisation, loaded from a JSON artifact written by eval/train.py."""
from __future__ import annotations

import json
from dataclasses import dataclass
from importlib import resources
from pathlib import Path

import numpy as np

from .config import PipelineConfig

DEFAULT_MODEL = "model.json"


@dataclass(frozen=True)
class VocalModel:
    version: str
    config: PipelineConfig
    kept_index: np.ndarray  # indices into the 600 high-level features
    center: np.ndarray  # per kept feature (training median, used for imputation and centring)
    scale: np.ndarray  # per kept feature (training SD)
    coef: np.ndarray
    intercept: float
    ref_mean: float  # raw score mean in the Reference population
    ref_sd: float
    quartile_cuts: np.ndarray  # 25th / 50th / 75th percentile of the z-scored biomarker

    def score(self, high_level: np.ndarray) -> float:
        """Vocal biomarker (z-score vs. the Reference population) for one Analysis window."""
        x = high_level[self.kept_index]
        x = np.where(np.isfinite(x), x, self.center)
        z = (x - self.center) / self.scale
        z = np.clip(z, -8, 8)  # high-order moments can explode on odd audio; keep one feature from dominating
        raw = float(z @ self.coef + self.intercept)
        return (raw - self.ref_mean) / self.ref_sd

    def quartile(self, biomarker: float) -> int:
        return int(np.searchsorted(self.quartile_cuts, biomarker, side="right") + 1)

    @classmethod
    def from_dict(cls, d: dict) -> "VocalModel":
        return cls(
            version=d["version"], config=PipelineConfig(**d["config"]),
            kept_index=np.asarray(d["kept_index"], dtype=int), center=np.asarray(d["center"], float),
            scale=np.asarray(d["scale"], float), coef=np.asarray(d["coef"], float),
            intercept=float(d["intercept"]), ref_mean=float(d["ref_mean"]), ref_sd=float(d["ref_sd"]),
            quartile_cuts=np.asarray(d["quartile_cuts"], float),
        )


def load(path: str | Path | None = None) -> VocalModel:
    if path is None:
        text = resources.files("voicebiomarker").joinpath("models", DEFAULT_MODEL).read_text(encoding="utf-8")
    else:
        text = Path(path).read_text(encoding="utf-8")
    return VocalModel.from_dict(json.loads(text))
