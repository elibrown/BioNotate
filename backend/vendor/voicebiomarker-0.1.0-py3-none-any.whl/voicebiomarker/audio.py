"""Decoding, voice activity detection and recording-quality metrics."""
from __future__ import annotations

import io
from pathlib import Path

import av
import librosa
import numpy as np

from .config import VAD_TOP_DB


class UndecodableAudio(ValueError):
    """The bytes are not audio PyAV can decode (a request error, not a Rejection)."""


def decode(source: bytes | str | Path, sample_rate: int) -> tuple[np.ndarray, float]:
    """Decode WAV / WebM / Ogg-Opus / anything FFmpeg reads into mono float32 at `sample_rate`.

    Returns (samples, clipping_fraction). Clipping is measured on the decoded signal before resampling.
    """
    try:
        container = av.open(io.BytesIO(source) if isinstance(source, (bytes, bytearray)) else str(source))
    except Exception as e:  # noqa: BLE001
        raise UndecodableAudio(f"could not open audio: {e}") from e
    try:
        stream = next((s for s in container.streams if s.type == "audio"), None)
        if stream is None:
            raise UndecodableAudio("no audio stream found")
        resampler = av.AudioResampler(format="flt", layout="mono", rate=sample_rate)
        raw_peaks, chunks = [], []
        for frame in container.decode(stream):
            native = frame.to_ndarray()
            if native.dtype.kind == "f":
                raw_peaks.append(np.abs(native).ravel() >= 0.999)
            elif native.dtype.kind in "iu":
                info = np.iinfo(native.dtype)
                raw_peaks.append((native.ravel() >= info.max - 1) | (native.ravel() <= info.min + 1))
            for out in resampler.resample(frame):
                chunks.append(out.to_ndarray().reshape(-1))
        for out in resampler.resample(None):
            chunks.append(out.to_ndarray().reshape(-1))
    except UndecodableAudio:
        raise
    except Exception as e:  # noqa: BLE001
        raise UndecodableAudio(f"could not decode audio: {e}") from e
    finally:
        container.close()
    if not chunks:  # a valid container with no samples: let the quality gate reject it with a reason
        return np.zeros(0, dtype=np.float32), 0.0
    y = np.concatenate(chunks).astype(np.float32)
    clip = float(np.concatenate(raw_peaks).mean()) if raw_peaks else 0.0
    return y, clip


def speech_intervals(y: np.ndarray, sr: int) -> np.ndarray:
    if y.size == 0:
        return np.zeros((0, 2), dtype=int)
    return librosa.effects.split(y, top_db=VAD_TOP_DB, frame_length=int(0.032 * sr), hop_length=sr // 100)


def speech_only(y: np.ndarray, sr: int) -> np.ndarray:
    """Concatenate the speech intervals (energy VAD)."""
    iv = speech_intervals(y, sr)
    if len(iv) == 0:
        return np.zeros(0, dtype=np.float32)
    return np.concatenate([y[a:b] for a, b in iv]).astype(np.float32)


def snr_db(y: np.ndarray, sr: int) -> float:
    """Speech level vs. noise floor: 95th vs. 10th percentile of 30 ms frame power, in dB.

    Call it on all Clips joined together, so the counting pauses supply noise-floor frames. Unlike the
    peak-relative VAD, it is not fooled by loud constant noise (which the VAD would count as speech).
    """
    if y.size < sr // 10:
        return float("-inf")
    p = librosa.feature.rms(y=y, frame_length=int(0.03 * sr), hop_length=int(0.01 * sr))[0] ** 2
    hi, lo = np.percentile(p, [95, 10])
    return float(10.0 * np.log10((hi + 1e-12) / (lo + 1e-12)))
