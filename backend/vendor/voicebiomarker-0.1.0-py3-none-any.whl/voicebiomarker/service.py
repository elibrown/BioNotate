"""FastAPI service [ADR 0001].

    uvicorn voicebiomarker.service:app --host 0.0.0.0 --port 8000
"""
from __future__ import annotations

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.responses import JSONResponse

from . import __version__, audio
from .api import RecordingTooLong, _default_model, analyze_clips
from .config import MAX_UPLOAD_BYTES, TASKS

ALLOWED_TYPES = {"audio/wav", "audio/x-wav", "audio/wave", "audio/vnd.wave", "audio/webm", "video/webm",
                 "audio/ogg", "audio/opus", "application/ogg", "application/octet-stream"}
ALLOWED_EXT = (".wav", ".webm", ".ogg", ".opus")

app = FastAPI(title="Vocal biomarker", version=__version__,
              description="Maor et al. (2020)-style Vocal biomarker from five Task Clips. Research use only; "
                          "not a diagnosis and has no clinical cutoff.")


@app.on_event("startup")
def _warm() -> None:
    _default_model()


@app.get("/healthz")
def healthz() -> dict:
    return {"status": "ok", "model_version": _default_model().version}


def _check_type(name: str, f: UploadFile) -> None:
    ctype = (f.content_type or "").split(";")[0].strip().lower()
    fname = (f.filename or "").lower()
    if ctype not in ALLOWED_TYPES and not fname.endswith(ALLOWED_EXT):
        raise HTTPException(415, f"{name}: unsupported type {ctype or fname!r}; send WAV, WebM or Ogg/Opus")


@app.post("/v1/analyze")
def analyze(  # sync def: FastAPI runs it in a worker thread [REQ Q20]
    counting_normal: UploadFile = File(..., description="Count 1-20 at a normal pace"),
    counting_fast: UploadFile = File(..., description="Count 1-20 fast"),
    vowel_a: UploadFile = File(..., description='Hold "aaa" for at least 5 s'),
    vowel_e: UploadFile = File(..., description='Hold "eee" for at least 5 s'),
    vowel_o: UploadFile = File(..., description='Hold "ooo" for at least 5 s'),
) -> JSONResponse:
    files = dict(zip(TASKS, (counting_normal, counting_fast, vowel_a, vowel_e, vowel_o)))
    data, total = {}, 0
    for name, f in files.items():
        _check_type(name, f)
        b = f.file.read(MAX_UPLOAD_BYTES + 1)
        total += len(b)
        if total > MAX_UPLOAD_BYTES:
            raise HTTPException(413, f"upload exceeds {MAX_UPLOAD_BYTES // (1024 * 1024)} MB in total")
        data[name] = b
    try:
        reading = analyze_clips(data)
    except audio.UndecodableAudio as e:
        raise HTTPException(400, str(e)) from e
    except RecordingTooLong as e:
        raise HTTPException(413, str(e)) from e
    return JSONResponse(reading.to_dict())
