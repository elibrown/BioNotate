"""Constants and pipeline configurations.

Tags follow docs/reverse-engineering/maor2020-spec.md:
[P] paper, [PAT] Vocalis patent US10796714B2, [INF] our inference, [REQ] project requirement / ADR.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass

# --------------------------------------------------------------------------- Tasks [REQ ADR 0002]
TASKS: tuple[str, ...] = ("counting_normal", "counting_fast", "vowel_a", "vowel_e", "vowel_o")
VOWEL_TASKS: tuple[str, ...] = ("vowel_a", "vowel_e", "vowel_o")
COUNTING_TASKS: tuple[str, ...] = ("counting_normal", "counting_fast")

# --------------------------------------------------------------------------- From the paper / patent
FRAMES_PER_SECOND = 100  # [P] "100 points per second"
FRAME_LENGTH_S = 0.032  # [PAT] 32 ms frames, 10 ms shift
N_MEL_BANDS = 26  # [PAT] 26-channel Mel filterbank
N_MOMENTS = 8  # [P] "eighth-order moments" -> 8 values per series [INF]
N_LOW_LEVEL = 75  # [INF] 600 / 8
N_HIGH_LEVEL = N_LOW_LEVEL * N_MOMENTS  # [P] 600

# --------------------------------------------------------------------------- Engineering constants (not in the papers)
VAD_TOP_DB = 30.0  # energy VAD: frames within 30 dB of the clip's peak count as speech
PITCH_FLOOR_HZ = 60.0
PITCH_CEILING_HZ = 500.0
PERTURBATION_HALF_WINDOW_S = 0.05  # jitter/shimmer series: +-50 ms around each frame
MAX_UPLOAD_BYTES = 10 * 1024 * 1024  # all five Clips together [REQ Q20]
MAX_AUDIO_S = 120.0  # all five Clips together, before VAD [REQ Q20]
CLIPPING_MAX_FRACTION = 0.01  # >1% of samples at full scale -> Rejection "clipping"
MIN_SNR_DB = 10.0  # speech vs. non-speech energy -> Rejection "low_snr"
MIN_VOWEL_NET_S = 0.5  # (Q13: 0.8 s rejected 6.3% of good Coswara Recordings) any Sustained vowel with less Net speech -> Rejection "vowel_too_short"


@dataclass(frozen=True)
class PipelineConfig:
    sample_rate: int
    moments: str  # "distribution" (H1) or "autocorr" (H2)
    stability_r: float  # keep a high-level feature if left/right-half Pearson r >= this
    drop_mfcc_means: bool  # equivalent to cepstral mean normalisation [ADR 0003]
    window_s: float  # length of one Analysis window
    min_net_speech_s: float  # Rejection "too_little_speech" below this
    two_windows_min_s: float  # with at least this much Net speech, average two disjoint windows

    def to_dict(self) -> dict:
        return asdict(self)


# Literal paper reading: 8 kHz telephone band, r >= 0.65, 20 s sample, one window.
PAPER_CONFIG = PipelineConfig(
    sample_rate=8000, moments="distribution", stability_r=0.65, drop_mfcc_means=False,
    window_s=20.0, min_net_speech_s=20.0, two_windows_min_s=float("inf"),
)

# Shipped defaults [ADR 0003]. `moments` is overwritten by the trained model artifact (eval/train.py
# picks H1 or H2 by cross-validated AUC [REQ Q22]); the artifact's config is what the service uses.
SHIPPED_CONFIG = PipelineConfig(
    sample_rate=16000, moments="distribution", stability_r=0.65, drop_mfcc_means=True,
    window_s=15.0, min_net_speech_s=15.0, two_windows_min_s=30.0,
)
