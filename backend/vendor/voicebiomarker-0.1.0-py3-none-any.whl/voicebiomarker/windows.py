"""Analysis windows: fixed amounts of Net speech with an equal share of every Task [ADR 0003].

A Sustained vowel often has less than its equal share (3 s of a 15 s window), so shares are
"water-filled": every Task gets min(what it has, an equal split of what is left), and any shortfall is
taken from the Tasks that have more. Each Task Clip is split in half; the first halves feed the left
half / first window, the second halves the right half / second window. That mirrors the paper's
left/right-half stability check (spec section 4).
"""
from __future__ import annotations

import numpy as np


def waterfill(pools: list[np.ndarray], n_samples: int) -> np.ndarray | None:
    """Take `n_samples` in total from `pools`, as evenly as possible. None if they hold too little."""
    avail = [len(p) for p in pools]
    if sum(avail) < n_samples or n_samples <= 0:
        return None
    alloc = [0] * len(pools)
    remaining = n_samples
    active = [i for i, a in enumerate(avail) if a > 0]
    while remaining > 0 and active:
        share = max(1, remaining // len(active))
        for i in list(active):
            take = min(share, avail[i] - alloc[i], remaining)
            alloc[i] += take
            remaining -= take
            if alloc[i] >= avail[i]:
                active.remove(i)
            if remaining == 0:
                break
    return np.concatenate([p[:a] for p, a in zip(pools, alloc) if a > 0])


def halves(clips: list[np.ndarray]) -> tuple[list[np.ndarray], list[np.ndarray]]:
    first = [c[: c.size // 2] for c in clips]
    second = [c[c.size // 2:] for c in clips]
    return first, second


def split_window(clips: list[np.ndarray], sr: int, window_s: float) -> tuple[np.ndarray, int] | None:
    """One window = left half from the first halves + right half from the second halves.

    Returns (window samples, index where the right half starts) or None if there is too little speech.
    """
    first, second = halves(clips)
    n_half = int(round(window_s * sr / 2))
    left, right = waterfill(first, n_half), waterfill(second, n_half)
    if left is None or right is None:
        return None
    return np.concatenate([left, right]), left.size


def disjoint_windows(clips: list[np.ndarray], sr: int, window_s: float) -> list[np.ndarray] | None:
    """Two windows that share no audio: one from the first halves, one from the second halves."""
    first, second = halves(clips)
    n = int(round(window_s * sr))
    a, b = waterfill(first, n), waterfill(second, n)
    if a is None or b is None:
        return None
    return [a, b]
