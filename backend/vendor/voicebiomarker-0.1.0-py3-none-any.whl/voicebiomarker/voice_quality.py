"""Voice-quality measures (Murton et al. 2017), reported next to the Vocal biomarker.

Vowel measures (F0 SD, CPP, CPP SD, jitter, shimmer, HNR) come from the Sustained vowels; median F0
and creak come from the Counting tasks (Murton's "passage" measures). Units are in the field names.
"""
from __future__ import annotations

import numpy as np
import parselmouth
from parselmouth.praat import call

from .config import PITCH_CEILING_HZ, PITCH_FLOOR_HZ
from .features import LOW_LEVEL_NAMES, low_level

_IDX = {n: i for i, n in enumerate(LOW_LEVEL_NAMES)}


def _trimmed(x: np.ndarray) -> np.ndarray:
    x = x[np.isfinite(x)]
    if x.size < 5:
        return x
    lo, hi = np.percentile(x, [5, 95])  # Murton: frames between 5th and 95th percentile
    return x[(x >= lo) & (x <= hi)]


def _r(v, nd=2):
    return None if v is None or not np.isfinite(v) else round(float(v), nd)


def _praat_vowel(y: np.ndarray, sr: int) -> dict[str, float]:
    snd = parselmouth.Sound(y.astype(np.float64), sampling_frequency=sr)
    pitch = snd.to_pitch_ac(pitch_floor=PITCH_FLOOR_HZ, pitch_ceiling=PITCH_CEILING_HZ)
    pp = call([snd, pitch], "To PointProcess (cc)")
    out = {"jitter": np.nan, "shimmer": np.nan, "hnr": np.nan}
    if call(pp, "Get number of points") > 10:
        out["jitter"] = call(pp, "Get jitter (local)", 0, 0, 0.0001, 0.02, 1.3)
        out["shimmer"] = call([snd, pp], "Get shimmer (local)", 0, 0, 0.0001, 0.02, 1.3, 1.6)
    hnr = snd.to_harmonicity_cc(minimum_pitch=PITCH_FLOOR_HZ)
    vals = hnr.values[0]
    vals = vals[vals > -199]
    if vals.size:
        out["hnr"] = float(vals.mean())
    return out


def creak_percent(M: np.ndarray) -> float:
    """Approximate creak %: share of phonated frames that are very low-pitched or aperiodic but loud.

    A heuristic stand-in for the Kane–Drugman neural creak detector Murton used (not available as an
    open Python package): phonated = loud frame (within 25 dB of the clip's 95th-percentile intensity);
    creaky = phonated and (F0 < 0.6 x median F0, or no F0 with a low zero-crossing rate).
    """
    f0, inten, zcr = M[_IDX["f0"]], M[_IDX["intensity_db"]], M[_IDX["zcr"]]
    loud = inten >= np.nanpercentile(inten, 95) - 25
    voiced = np.isfinite(f0)
    if voiced.sum() < 10:
        return float("nan")
    med = np.nanmedian(f0)
    low_pitch = voiced & (f0 < 0.6 * med)
    aperiodic = ~voiced & (zcr < 0.1)
    phonated = loud & (voiced | aperiodic)
    if phonated.sum() == 0:
        return float("nan")
    return 100.0 * float(np.sum(phonated & (low_pitch | aperiodic)) / phonated.sum())


def measure(counting: list[np.ndarray], vowels: list[np.ndarray], sr: int) -> dict[str, float | None]:
    out: dict[str, float | None] = dict.fromkeys(
        ["f0_median_hz", "f0_sd_hz", "cpp_db", "cpp_sd_db", "jitter_pct", "shimmer_pct", "hnr_db", "creak_pct"])
    if counting and sum(c.size for c in counting) > sr:
        Mc, _ = low_level(np.concatenate(counting), sr)
        out["f0_median_hz"] = _r(np.median(_trimmed(Mc[_IDX["f0"]])) if np.isfinite(Mc[_IDX["f0"]]).any() else None, 1)
        out["creak_pct"] = _r(creak_percent(Mc), 1)
    vowels = [v for v in vowels if v.size > sr // 2]
    if vowels:
        Mv, _ = low_level(np.concatenate(vowels), sr)
        f0 = _trimmed(Mv[_IDX["f0"]])
        cpp = Mv[_IDX["cpp"]]
        cpp = cpp[np.isfinite(cpp)]
        out["f0_sd_hz"] = _r(np.std(f0) if f0.size >= 5 else None)
        out["cpp_db"] = _r(cpp.mean() if cpp.size else None)
        out["cpp_sd_db"] = _r(cpp.std() if cpp.size else None)
        per = [_praat_vowel(v, sr) for v in vowels]
        out["jitter_pct"] = _r(100 * np.nanmean([p["jitter"] for p in per]), 3)
        out["shimmer_pct"] = _r(100 * np.nanmean([p["shimmer"] for p in per]), 2)
        out["hnr_db"] = _r(np.nanmean([p["hnr"] for p in per]), 1)
    return out
