"""Raw RGB trace buffer and resampling to the fixed processing rate."""
import numpy as np

from .config import FS, WINDOW_S


def resample_window(ts: np.ndarray, rgb: np.ndarray, t_end: float, window_s: float = WINDOW_S,
                    fs: float = FS) -> np.ndarray:
    """Linear-interpolate (ts, rgb) onto an even grid covering [t_end - window_s, t_end]."""
    n = int(round(window_s * fs))
    grid = t_end - (np.arange(n)[::-1] / fs)
    return np.column_stack([np.interp(grid, ts, rgb[:, c]) for c in range(3)])


class TraceBuffer:
    """Keeps the last `window_s` (+ margin) of timestamped RGB means."""

    def __init__(self, window_s: float = WINDOW_S):
        self.window_s = window_s
        self.ts: list[float] = []
        self.rgb: list[np.ndarray] = []

    def clear(self) -> None:
        self.ts.clear()
        self.rgb.clear()

    def append(self, ts: float, rgb: np.ndarray) -> None:
        self.ts.append(ts)
        self.rgb.append(rgb)
        cutoff = ts - self.window_s - 1.0
        while len(self.ts) > 2 and self.ts[1] < cutoff:
            self.ts.pop(0)
            self.rgb.pop(0)

    def span(self) -> float:
        return self.ts[-1] - self.ts[0] if self.ts else 0.0

    def window(self) -> np.ndarray:
        return resample_window(np.asarray(self.ts), np.asarray(self.rgb), self.ts[-1], self.window_s)
