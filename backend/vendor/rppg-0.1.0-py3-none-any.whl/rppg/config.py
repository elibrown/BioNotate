"""Pipeline constants (from the paper) and the internal experiment configuration."""
from dataclasses import dataclass

# --- Paper constants (Poh et al. 2010, section 2.3) ---
WINDOW_S = 30.0          # moving window length
STEP_S = 1.0             # window increment (96.7% overlap)
BAND_HZ = (0.75, 4.0)    # operational band, 45-240 bpm
MAX_JUMP_BPM = 12.0      # max change between successive estimates
ROI_WIDTH_FRAC = 0.6     # centre 60% width, full height of face box

# --- Engineering constants (not in paper) ---
FS = 15.0                # processing rate: frames decimated + traces resampled to this
FACE_GRACE_S = 1.0       # reuse previous face box for gaps up to this long
NFFT_MIN = 4096          # zero-padding for finer spectral resolution


@dataclass(frozen=True)
class PipelineConfig:
    """Internal experiment switches. The public API uses SHIPPED_CONFIG only."""
    detector: str = "haar"        # "haar" (paper) | "mediapipe"
    ica: str = "jade"             # "jade" (paper) | "fastica" | "green" (no ICA, raw green channel)
    selection: str = "second"     # "second" (paper) | "max_peak"
    prefilter: bool = False       # detrend + bandpass before ICA (Poh 2011)
    jump_rule: bool = True        # paper's 12 bpm max-change rejection

    def name(self) -> str:
        return (f"{self.detector}/{self.ica}/{self.selection}/{'pre' if self.prefilter else 'raw'}"
                f"/{'jump' if self.jump_rule else 'nojump'}")


PAPER_CONFIG = PipelineConfig()

# Evaluation winner on UBFC-rPPG DATASET_2 (MAE 3.96 bpm vs 23.42 for the paper config; see DESIGN.md).
SHIPPED_CONFIG = PipelineConfig(detector="haar", ica="fastica", selection="max_peak", prefilter=True)
