"""Public API: streaming PulseEstimator and offline estimate_video (built on the same push path)."""
from dataclasses import dataclass
import math

import cv2
import numpy as np

from .config import FS, SHIPPED_CONFIG, STEP_S, WINDOW_S, PipelineConfig
from .face import FaceTracker, make_detector, roi_mean_rgb
from .hr import HREstimator
from .traces import TraceBuffer

STATUS_OK = "ok"
STATUS_NO_FACE = "no face detected"


@dataclass(frozen=True)
class Reading:
    hr_bpm: float | None
    status: str


class PulseEstimator:
    """Feed webcam frames with timestamps; get heart-rate readings.

    >>> est = PulseEstimator()
    >>> reading = est.push(frame_bgr, timestamp_seconds)
    >>> reading.hr_bpm, reading.status
    """

    def __init__(self, _config: PipelineConfig | None = None, _detector=None):
        cfg = _config or SHIPPED_CONFIG
        self._tracker = FaceTracker(_detector or make_detector(cfg.detector))
        self._buffer = TraceBuffer()
        self._hr = HREstimator(cfg)
        self._next_due: float | None = None
        self._last_est_ts: float | None = None
        self._reading = Reading(None, STATUS_NO_FACE)
        self.new_estimate = False  # True iff the last push produced a fresh HR value

    def reset(self) -> None:
        self._tracker.reset()
        self._buffer.clear()
        self._hr.reset()
        self._last_est_ts = None

    def push(self, frame_bgr: np.ndarray, timestamp: float) -> Reading:
        """frame_bgr: HxWx3 uint8 BGR (OpenCV) image. timestamp: seconds, monotonic."""
        self.new_estimate = False
        # Decimate to ~FS frames/s before the (expensive) face detection.
        if self._next_due is not None and timestamp < self._next_due - 0.25 / FS:
            return self._reading
        self._next_due = max((self._next_due or timestamp) + 1 / FS, timestamp + 0.5 / FS)

        box = self._tracker.update(frame_bgr, timestamp)
        rgb = roi_mean_rgb(frame_bgr, box) if box is not None else None
        if rgb is None:
            self.reset()
            self._reading = Reading(None, STATUS_NO_FACE)
            return self._reading

        self._buffer.append(timestamp, rgb)
        remaining = WINDOW_S - self._buffer.span()
        if remaining > 0.5 / FS:
            self._reading = Reading(None, f"collecting data: {math.ceil(remaining)} s remaining")
            return self._reading

        if self._last_est_ts is None or timestamp - self._last_est_ts >= STEP_S - 0.5 / FS:
            self._last_est_ts = timestamp
            self._reading = Reading(round(self._hr.estimate(self._buffer.window()), 1), STATUS_OK)
            self.new_estimate = True
        return self._reading


def estimate_video(path: str, _config: PipelineConfig | None = None, _detector=None) -> list[tuple[float, float]]:
    """Run the streaming estimator over a video file. Returns [(timestamp_s, hr_bpm), ...] per new estimate."""
    cap = cv2.VideoCapture(str(path))
    if not cap.isOpened():
        raise IOError(f"cannot open video: {path}")
    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    est = PulseEstimator(_config, _detector)
    out, i = [], 0
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        ts = i / fps
        r = est.push(frame, ts)
        if est.new_estimate:
            out.append((ts, r.hr_bpm))
        i += 1
    cap.release()
    return out
