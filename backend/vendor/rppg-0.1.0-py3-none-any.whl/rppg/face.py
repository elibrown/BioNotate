"""Face detection + single-subject tracking + ROI (paper section 2.3)."""
from pathlib import Path

import cv2
import numpy as np

from .config import FACE_GRACE_S, ROI_WIDTH_FRAC

Box = tuple[int, int, int, int]  # x, y, w, h

# Bundled models (no network needed at runtime):
#  - OpenCV frontal Haar cascade (opencv/opencv 4.x data/haarcascades; OpenCV 5 wheels no longer ship it)
#  - MediaPipe BlazeFace short-range (storage.googleapis.com/mediapipe-models/face_detector/...)
MODELS_DIR = Path(__file__).parent / "models"
HAAR_PATH = MODELS_DIR / "haarcascade_frontalface_default.xml"
MP_MODEL_PATH = MODELS_DIR / "blaze_face_short_range.tflite"


class HaarDetector:
    """OpenCV Viola-Jones frontal face cascade (as in the paper)."""

    def __init__(self):
        self._cascade = cv2.CascadeClassifier(str(HAAR_PATH))
        if self._cascade.empty():
            raise RuntimeError("failed to load Haar cascade")

    def detect(self, frame_bgr: np.ndarray) -> list[Box]:
        gray = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2GRAY)
        faces = self._cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(60, 60))
        return [tuple(int(v) for v in f) for f in faces]


class MediaPipeDetector:
    """MediaPipe BlazeFace (short range) via the Tasks API."""

    def __init__(self, min_confidence: float = 0.5):
        import mediapipe as mp
        from mediapipe.tasks.python import BaseOptions, vision

        self._mp = mp
        self._det = vision.FaceDetector.create_from_options(
            vision.FaceDetectorOptions(
                base_options=BaseOptions(model_asset_path=str(MP_MODEL_PATH)),
                min_detection_confidence=min_confidence,
            )
        )

    def detect(self, frame_bgr: np.ndarray) -> list[Box]:
        rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
        res = self._det.detect(self._mp.Image(image_format=self._mp.ImageFormat.SRGB, data=rgb))
        boxes = []
        for d in res.detections:
            b = d.bounding_box
            boxes.append((int(b.origin_x), int(b.origin_y), int(b.width), int(b.height)))
        return boxes


def make_detector(name: str):
    return {"haar": HaarDetector, "mediapipe": MediaPipeDetector}[name]()


def roi(box: Box) -> Box:
    """Centre 60% width, full height of the face box."""
    x, y, w, h = box
    rw = int(round(w * ROI_WIDTH_FRAC))
    return x + (w - rw) // 2, y, rw, h


def roi_mean_rgb(frame_bgr: np.ndarray, box: Box) -> np.ndarray | None:
    """Spatial mean of R, G, B over the ROI (clipped to frame)."""
    x, y, w, h = roi(box)
    H, W = frame_bgr.shape[:2]
    x0, y0, x1, y1 = max(x, 0), max(y, 0), min(x + w, W), min(y + h, H)
    if x1 <= x0 or y1 <= y0:
        return None
    return frame_bgr[y0:y1, x0:x1].reshape(-1, 3).mean(axis=0)[::-1].astype(float)


class FaceTracker:
    """Single subject: nearest face to the previous box; reuse previous box for gaps <= grace."""

    def __init__(self, detector, grace_s: float = FACE_GRACE_S):
        self.detector = detector
        self.grace_s = grace_s
        self.box: Box | None = None
        self.box_ts: float | None = None

    def reset(self) -> None:
        self.box, self.box_ts = None, None

    def update(self, frame_bgr: np.ndarray, ts: float) -> Box | None:
        """Returns the box to use for this frame, or None if the face is lost."""
        faces = self.detector.detect(frame_bgr)
        if faces:
            if self.box is None:
                self.box = max(faces, key=lambda f: f[2] * f[3])
            else:
                cx, cy = self.box[0] + self.box[2] / 2, self.box[1] + self.box[3] / 2
                self.box = min(faces, key=lambda f: (f[0] + f[2] / 2 - cx) ** 2 + (f[1] + f[3] / 2 - cy) ** 2)
            self.box_ts = ts
            return self.box
        if self.box is not None and ts - self.box_ts <= self.grace_s:
            return self.box
        self.reset()
        return None
