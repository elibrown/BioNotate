"""Heart rate, respiratory rate and pulse-respiration quotient from a face video recording.

HR: Poh, McDuff & Picard (2010) with evaluated fixes. RR: Verkruysse, Svaasand & Nelson (2008).
"""
from .api import Reading, analyze_file

__all__ = ["Reading", "analyze_file"]
