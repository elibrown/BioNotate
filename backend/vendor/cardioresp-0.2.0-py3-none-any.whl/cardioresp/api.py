"""Public API: analyze_file(path) -> list[Reading].

`Session.push_frame` is the per-frame engine underneath analyze_file. It exists for tests and
evaluation only and is not part of the public API (docs/adr/0002-file-only-api.md).
"""
from collections import deque
from dataclasses import dataclass
import math
from pathlib import Path

import cv2
import numpy as np

from .config import FS, MIN_FPS, SHIPPED_CONFIG, STEP_S, WINDOW_S, PipelineConfig
from .face import FaceTracker, box_mean_rgb, make_detector, roi_mean_rgb
from .hr import HREstimator
from .rr import estimate_rr
from .traces import TraceBuffer

STATUS_OK = "ok"
STATUS_WARMING_UP = "warming_up"
STATUS_NO_FACE = "no_face"
STATUS_PARTIAL = "partial"

_TOL = 0.5 / FS  # timing tolerance: half a processing sample


@dataclass(frozen=True)
class Reading:
    """Values for one analysis window, stamped with the window's end time.

    hr_bpm, respi_rate and prq come from the same window, so they are synchronised by construction.
    status is one of "ok", "warming_up", "no_face", "partial"; log_message is human-readable.
    """
    ts: float
    hr_bpm: float | None
    respi_rate: float | None
    prq: float | None
    status: str
    log_message: str


class Session:
    """Per-recording estimator state. Feed frames in timestamp order; every STEP_S of video time
    push_frame returns a Reading (and None in between)."""

    def __init__(self, _config: PipelineConfig | None = None, _detector=None):
        self.cfg = _config or SHIPPED_CONFIG
        self._tracker = FaceTracker(_detector or make_detector(self.cfg.detector))
        self._buffer = TraceBuffer(self.cfg.analysis_window_s)
        self._hr = HREstimator(self.cfg)
        self._hr_history: deque[tuple[float, float]] = deque()
        self._next_due: float | None = None   # next frame to process (decimation to ~FS)
        self._next_emit: float | None = None  # next reading time
        self._face = False

    def _reset_signal(self) -> None:
        self._tracker.reset()
        self._buffer.clear()
        self._hr.reset()
        self._hr_history.clear()

    def push_frame(self, frame_bgr: np.ndarray, timestamp: float) -> Reading | None:
        """frame_bgr: HxWx3 uint8 BGR (OpenCV) image. timestamp: seconds, increasing."""
        if self._next_emit is None:
            self._next_emit = timestamp + STEP_S
        # Decimate to ~FS frames/s before the (expensive) face detection.
        if self._next_due is not None and timestamp < self._next_due - _TOL / 2:
            return None
        self._next_due = max((self._next_due or timestamp) + 1 / FS, timestamp + 0.5 / FS)

        box = self._tracker.update(frame_bgr, timestamp)
        hr_rgb = roi_mean_rgb(frame_bgr, box) if box is not None else None
        rr_rgb = box_mean_rgb(frame_bgr, box) if box is not None else None
        if hr_rgb is None or rr_rgb is None:
            if self._face:
                self._reset_signal()
            self._face = False
        else:
            self._face = True
            self._buffer.append(timestamp, hr_rgb, rr_rgb)

        if timestamp < self._next_emit - _TOL:
            return None
        self._next_emit += STEP_S * max(1, math.floor((timestamp - self._next_emit) / STEP_S + _TOL) + 1)
        return self._reading(timestamp)

    def _reading(self, ts: float) -> Reading:
        ts = round(ts, 3)
        if not self._face:
            return Reading(ts, None, None, None, STATUS_NO_FACE, "no face detected")
        span = self._buffer.span()
        if span < WINDOW_S - _TOL:
            return Reading(ts, None, None, None, STATUS_WARMING_UP,
                           f"collecting data: {max(1, round(WINDOW_S - span))} s remaining")

        hr_now = self._hr.estimate(self._buffer.hr_window(WINDOW_S))
        self._hr_history.append((ts, hr_now))
        rr_win = self.cfg.rr_window_s
        while self._hr_history and self._hr_history[0][0] < ts - (rr_win - WINDOW_S) - _TOL:
            self._hr_history.popleft()

        if span < rr_win - _TOL:
            return Reading(ts, round(hr_now, 1), None, None, STATUS_PARTIAL,
                           f"collecting breathing data: {max(1, round(rr_win - span))} s remaining")

        # HR averaged over the HR windows that lie inside the RR window (= hr_now when both are 30 s).
        hr = float(np.mean([h for _, h in self._hr_history]))
        est = estimate_rr(self._buffer.rr_window(rr_win), FS, hr, self.cfg.rr_hr_exclusion)
        if est is None:
            return Reading(ts, round(hr, 1), None, None, STATUS_PARTIAL,
                           "breathing rate unavailable: no usable colour signal")
        hr_out, rr_out = round(hr, 1), round(est.rr_bpm, 1)
        # PRQ from the reported values, so hr_bpm / respi_rate == prq for the consumer.
        return Reading(ts, hr_out, rr_out, round(hr_out / rr_out, 2), STATUS_OK, "ok")


def analyze_file(path: str | Path, _config: PipelineConfig | None = None, _detector=None) -> list[Reading]:
    """Analyse a recording file (mp4, mkv, webm, avi; any audio track is ignored).

    Returns one Reading per second of video. The first 30 s are warm-up (status "warming_up").
    Raises FileNotFoundError if the file is missing, ValueError if it can't be decoded, is shorter
    than 30 s, or its frame rate is below 15 fps.
    """
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(f"recording not found: {path}")
    cap = cv2.VideoCapture(str(path))
    if not cap.isOpened():
        raise ValueError(f"cannot decode video: {path}")
    try:
        fps = cap.get(cv2.CAP_PROP_FPS)
        n_frames = cap.get(cv2.CAP_PROP_FRAME_COUNT)
        sane_header = 0 < fps <= 240 and n_frames > 0
        if sane_header:
            _check_recording(fps, n_frames / fps)
        step = 1.0 / fps if 0 < fps <= 240 else 1.0 / 30.0

        session = Session(_config, _detector)
        readings, prev_t, n = [], None, 0
        while True:
            ok, frame = cap.read()
            if not ok:
                break
            # Prefer container timestamps (variable frame rate, e.g. browser webm); fall back to n/fps.
            t = cap.get(cv2.CAP_PROP_POS_MSEC) / 1000.0
            if prev_t is not None and not t > prev_t:
                t = prev_t + step
            elif prev_t is None:
                t = max(t, 0.0)
            prev_t, n = t, n + 1
            r = session.push_frame(frame, t)
            if r is not None:
                readings.append(r)
    finally:
        cap.release()

    if n == 0:
        raise ValueError(f"no decodable video frames: {path}")
    if not sane_header:
        _check_recording(n / max(prev_t, 1e-9), prev_t)
    return readings


def _check_recording(fps: float, duration_s: float) -> None:
    if duration_s < WINDOW_S - 0.5:
        raise ValueError(f"recording is {duration_s:.1f} s long; at least {WINDOW_S:.0f} s is required")
    if fps < MIN_FPS - 0.5:
        raise ValueError(f"recording is {fps:.1f} fps; at least {MIN_FPS:.0f} fps is required")
