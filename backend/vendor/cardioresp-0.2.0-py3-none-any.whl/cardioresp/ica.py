"""Blind source separation backends: JADE (in-house, Cardoso 1999) and FastICA (scikit-learn)."""
import numpy as np


def jade(X: np.ndarray, max_sweeps: int = 100) -> np.ndarray:
    """Real-valued JADE (port of Cardoso's jadeR). X: (m, T) observations -> (m, T) sources.

    Sources are ordered by decreasing energy of their mixing columns, as in jadeR,
    which is what makes "the second component" well defined.
    """
    X = np.asarray(X, dtype=float)
    X = X - X.mean(axis=1, keepdims=True)
    m, T = X.shape

    # Whitening
    D, U = np.linalg.eigh(X @ X.T / T)
    order = np.argsort(D)[::-1]
    D, U = D[order], U[:, order]
    B = (U / np.sqrt(D)).T                  # (m, m)
    Y = B @ X

    # Fourth-order cumulant matrices
    nbcm = m * (m + 1) // 2
    CM = np.zeros((m, m * nbcm))
    R = np.eye(m)
    k = 0
    for i in range(m):
        Yi = Y[i]
        Q = ((Yi * Yi) * Y) @ Y.T / T - R - 2 * np.outer(R[:, i], R[:, i])
        CM[:, k * m:(k + 1) * m] = Q
        k += 1
        for j in range(i):
            Q = ((Yi * Y[j]) * Y) @ Y.T / T - np.outer(R[:, i], R[:, j]) - np.outer(R[:, j], R[:, i])
            CM[:, k * m:(k + 1) * m] = np.sqrt(2) * Q
            k += 1

    # Joint approximate diagonalisation by Givens rotations
    V = np.eye(m)
    threshold = 1e-6 / np.sqrt(T)
    for _ in range(max_sweeps):
        rotated = False
        for p in range(m - 1):
            for q in range(p + 1, m):
                Ip = np.arange(p, m * nbcm, m)
                Iq = np.arange(q, m * nbcm, m)
                g = np.vstack([CM[p, Ip] - CM[q, Iq], CM[p, Iq] + CM[q, Ip]])
                gg = g @ g.T
                ton = gg[0, 0] - gg[1, 1]
                toff = gg[0, 1] + gg[1, 0]
                theta = 0.5 * np.arctan2(toff, ton + np.sqrt(ton * ton + toff * toff))
                if abs(theta) > threshold:
                    rotated = True
                    c, s = np.cos(theta), np.sin(theta)
                    G = np.array([[c, -s], [s, c]])
                    pair = [p, q]
                    V[:, pair] = V[:, pair] @ G
                    CM[pair, :] = G.T @ CM[pair, :]
                    cp, cq = CM[:, Ip].copy(), CM[:, Iq].copy()
                    CM[:, Ip] = c * cp + s * cq
                    CM[:, Iq] = -s * cp + c * cq
        if not rotated:
            break

    W = V.T @ B
    # Sort by energy of mixing columns (most energetic first), fix signs
    A = np.linalg.pinv(W)
    W = W[np.argsort((A ** 2).sum(axis=0))[::-1]]
    W = W * np.sign(np.sign(W[:, [0]]) + 0.1)
    return W @ X


def fastica(X: np.ndarray, seed: int = 0) -> np.ndarray:
    """scikit-learn FastICA. X: (m, T) -> (m, T). Component order is arbitrary."""
    from sklearn.decomposition import FastICA

    ica = FastICA(n_components=X.shape[0], whiten="unit-variance", random_state=seed, max_iter=1000)
    return ica.fit_transform(np.asarray(X, dtype=float).T).T
