"""Window -> respiratory rate from the whole-face colour signal (Verkruysse, Svaasand & Nelson 2008).

Per colour channel: band-pass with a 4th-order Butterworth applied forward and reverse, zero-padded
FFT, peak in the RR band. Verkruysse found the RR signal strongest in different channels in different
recordings (blue in Fig. 1, green in Fig. 3), so instead of fixing one channel we take the channel
whose spectrum is most concentrated at its peak (the same rule that fixed component selection for HR).
"""
from dataclasses import dataclass

import numpy as np
from scipy import signal

from .config import FS, RR_BAND_HZ, RR_FILTER_ORDER, RR_HR_EXCLUSION_HZ, RR_NFFT_MIN


@dataclass(frozen=True)
class RREstimate:
    rr_bpm: float
    quality: float   # fraction of in-band power within one resolution bin of the peak (0-1)
    channel: int     # 0=R, 1=G, 2=B


def bandpass(x: np.ndarray, fs: float = FS) -> np.ndarray:
    """PV_BP(t): linear detrend (limits filter edge effects), then zero-phase Butterworth band-pass."""
    sos = signal.butter(RR_FILTER_ORDER, [RR_BAND_HZ[0], RR_BAND_HZ[1]], btype="band", fs=fs, output="sos")
    return signal.sosfiltfilt(sos, signal.detrend(x, axis=0), axis=0)


def rr_spectrum(x: np.ndarray, fs: float = FS) -> tuple[np.ndarray, np.ndarray]:
    """Zero-padded power spectrum of a 1-D signal, restricted to the RR band."""
    nfft = max(RR_NFFT_MIN, len(x))
    freqs = np.fft.rfftfreq(nfft, 1 / fs)
    power = np.abs(np.fft.rfft(x - x.mean(), nfft)) ** 2
    band = (freqs >= RR_BAND_HZ[0]) & (freqs <= RR_BAND_HZ[1])
    return freqs[band], power[band]


def estimate_rr(rgb: np.ndarray, fs: float = FS, hr_bpm: float | None = None,
                hr_exclusion: bool = False) -> RREstimate | None:
    """rgb: (N, 3) evenly sampled whole-face R, G, B means. Returns None for a flat (degenerate) window."""
    filtered = bandpass(np.asarray(rgb, dtype=float), fs)
    window_s = len(rgb) / fs
    best = None
    for c in range(filtered.shape[1]):
        freqs, p = rr_spectrum(filtered[:, c], fs)
        if hr_exclusion and hr_bpm is not None:
            p = np.where(np.abs(freqs - hr_bpm / 60.0) <= RR_HR_EXCLUSION_HZ, 0.0, p)
        total = p.sum()
        if total <= 0:
            continue
        i = int(np.argmax(p))
        near = np.abs(freqs - freqs[i]) <= 1.0 / window_s   # one natural resolution bin either side
        quality = float(p[near].sum() / total)
        if best is None or quality > best.quality:
            best = RREstimate(float(freqs[i] * 60.0), quality, c)
    return best
