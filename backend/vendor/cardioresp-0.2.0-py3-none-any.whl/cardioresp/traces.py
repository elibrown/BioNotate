"""Raw colour trace buffer and resampling to the fixed processing rate."""
import numpy as np

from .config import FS


def resample_window(ts: np.ndarray, rgb: np.ndarray, t_end: float, window_s: float,
                    fs: float = FS) -> np.ndarray:
    """Linear-interpolate (ts, rgb) onto an even grid covering [t_end - window_s, t_end]."""
    n = int(round(window_s * fs))
    grid = t_end - (np.arange(n)[::-1] / fs)
    return np.column_stack([np.interp(grid, ts, rgb[:, c]) for c in range(rgb.shape[1])])


class TraceBuffer:
    """Keeps the last `keep_s` seconds of timestamped colour means for both regions:
    the HR region (centre of the face) and the RR region (whole face)."""

    def __init__(self, keep_s: float):
        self.keep_s = keep_s
        self.ts: list[float] = []
        self.hr_rgb: list[np.ndarray] = []
        self.rr_rgb: list[np.ndarray] = []

    def clear(self) -> None:
        self.ts.clear()
        self.hr_rgb.clear()
        self.rr_rgb.clear()

    def append(self, ts: float, hr_rgb: np.ndarray, rr_rgb: np.ndarray) -> None:
        self.ts.append(ts)
        self.hr_rgb.append(hr_rgb)
        self.rr_rgb.append(rr_rgb)
        cutoff = ts - self.keep_s - 1.0
        while len(self.ts) > 2 and self.ts[1] < cutoff:
            self.ts.pop(0)
            self.hr_rgb.pop(0)
            self.rr_rgb.pop(0)

    def span(self) -> float:
        return self.ts[-1] - self.ts[0] if self.ts else 0.0

    def hr_window(self, window_s: float) -> np.ndarray:
        return resample_window(np.asarray(self.ts), np.asarray(self.hr_rgb), self.ts[-1], window_s)

    def rr_window(self, window_s: float) -> np.ndarray:
        return resample_window(np.asarray(self.ts), np.asarray(self.rr_rgb), self.ts[-1], window_s)
