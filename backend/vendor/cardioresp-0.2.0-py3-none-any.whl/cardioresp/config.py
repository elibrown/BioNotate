"""Pipeline constants (from the papers) and the internal experiment configuration."""
from dataclasses import dataclass

# --- HR: Poh, McDuff & Picard 2010, section 2.3 ---
WINDOW_S = 30.0          # HR analysis window length
STEP_S = 1.0             # one reading per second
BAND_HZ = (0.75, 4.0)    # HR operational band, 45-240 bpm
MAX_JUMP_BPM = 12.0      # paper's max change between successive HR estimates
ROI_WIDTH_FRAC = 0.6     # HR region: centre 60% width, full height of the face box

# --- RR: Verkruysse, Svaasand & Nelson 2008 ---
RR_BAND_HZ = (0.1, 0.7)  # 6-42 breaths/min (Verkruysse observed 0.12-0.3 Hz)
RR_FILTER_ORDER = 4      # 4th-order Butterworth, applied forward and reverse ("filtfilt")
RR_HR_EXCLUSION_HZ = 0.1  # half-width of the band removed around the HR frequency (when enabled)

# --- Engineering constants (not in the papers) ---
FS = 15.0                # processing rate: frames decimated + traces resampled to this
FACE_GRACE_S = 1.0       # reuse previous face box for gaps up to this long
NFFT_MIN = 4096          # zero-padding for HR spectra
RR_NFFT_MIN = 16384      # zero-padding for RR spectra (~0.05 breaths/min bins at 15 Hz)
MIN_FPS = 15.0           # recordings below this frame rate are rejected


@dataclass(frozen=True)
class PipelineConfig:
    """Internal experiment switches. The public API uses SHIPPED_CONFIG only."""
    detector: str = "haar"        # "haar" (paper) | "mediapipe"
    ica: str = "jade"             # "jade" (paper) | "fastica" | "green" (no ICA, raw green channel)
    selection: str = "second"     # "second" (paper) | "max_peak"
    prefilter: bool = False       # detrend + bandpass before ICA (Poh 2011)
    jump_rule: bool = True        # paper's 12 bpm max-change rejection
    rr_window_s: float = 30.0     # RR analysis window; HR is averaged over the same span
    rr_hr_exclusion: bool = False  # ignore RR spectrum power near the HR frequency

    def name(self) -> str:
        return (f"{self.detector}/{self.ica}/{self.selection}/{'pre' if self.prefilter else 'raw'}"
                f"/{'jump' if self.jump_rule else 'nojump'}"
                f"/rr{int(self.rr_window_s)}{'/hrx' if self.rr_hr_exclusion else ''}")

    @property
    def analysis_window_s(self) -> float:
        """Span covered by one reading: the longer of the HR and RR windows."""
        return max(WINDOW_S, self.rr_window_s)


PAPER_CONFIG = PipelineConfig()

# HR part: winner on UBFC-rPPG DATASET_2 (DESIGN.md), with the jump rule off, which improved both
# UBFC sets (DATASET_2 MAE 3.96 -> 2.73, DATASET_1 1.31 -> 0.95).
# RR part: chosen by eval/evaluate.py (see DESIGN.md).
SHIPPED_CONFIG = PipelineConfig(detector="haar", ica="fastica", selection="max_peak", prefilter=True,
                                jump_rule=False, rr_window_s=30.0, rr_hr_exclusion=False)
