"""Window -> heart rate: normalise, (prefilter), ICA, select component, FFT peak, jump rejection."""
import numpy as np
from scipy import signal

from .config import BAND_HZ, FS, MAX_JUMP_BPM, NFFT_MIN, PipelineConfig
from .ica import fastica, jade


def zscore(X: np.ndarray) -> np.ndarray:
    """Eq. (3): per-row zero mean, unit variance."""
    sd = X.std(axis=1, keepdims=True)
    return (X - X.mean(axis=1, keepdims=True)) / np.where(sd > 0, sd, 1.0)


def prefilter(X: np.ndarray, fs: float = FS) -> np.ndarray:
    """Detrend + bandpass (Poh 2011-style improvement)."""
    X = signal.detrend(X, axis=1)
    b, a = signal.butter(3, [BAND_HZ[0] / (fs / 2), BAND_HZ[1] / (fs / 2)], btype="band")
    return signal.filtfilt(b, a, X, axis=1)


def power_spectrum(x: np.ndarray, fs: float = FS) -> tuple[np.ndarray, np.ndarray]:
    """Power spectrum restricted to the operational band."""
    nfft = max(NFFT_MIN, len(x))
    freqs = np.fft.rfftfreq(nfft, 1 / fs)
    power = np.abs(np.fft.rfft(x - x.mean(), nfft)) ** 2
    band = (freqs >= BAND_HZ[0]) & (freqs <= BAND_HZ[1])
    return freqs[band], power[band]


def peak_snr(x: np.ndarray, fs: float = FS) -> float:
    """Fraction of in-band power at the peak (+/- 1 bin neighbourhood); used for max_peak selection."""
    _, p = power_spectrum(x, fs)
    i = int(np.argmax(p))
    return float(p[max(i - 2, 0):i + 3].sum() / p.sum())


def pick_hr(x: np.ndarray, prev_hr: float | None, fs: float = FS, max_jump: float | None = MAX_JUMP_BPM) -> float:
    """Highest in-band peak; if it jumps > max_jump from prev_hr, try next-highest peaks; else keep prev_hr."""
    freqs, p = power_spectrum(x, fs)
    peaks, _ = signal.find_peaks(p)
    if len(peaks) == 0:
        peaks = np.array([int(np.argmax(p))])
    bpms = freqs[peaks[np.argsort(p[peaks])[::-1]]] * 60.0
    if prev_hr is None or max_jump is None:
        return float(bpms[0])
    for bpm in bpms:
        if abs(bpm - prev_hr) <= max_jump:
            return float(bpm)
    return float(prev_hr)


def source_signal(rgb: np.ndarray, cfg: PipelineConfig, fs: float = FS) -> np.ndarray:
    """rgb: (N, 3) evenly sampled R,G,B traces -> 1-D pulse source signal."""
    X = zscore(rgb.T)
    if cfg.prefilter:
        X = zscore(prefilter(X, fs))
    if cfg.ica == "green":
        return X[1]
    S = jade(X) if cfg.ica == "jade" else fastica(X)
    if cfg.selection == "second":
        return S[1]
    return S[int(np.argmax([peak_snr(s, fs) for s in S]))]


class HREstimator:
    """Stateful per-window HR estimator (holds previous HR for jump rejection)."""

    def __init__(self, cfg: PipelineConfig):
        self.cfg = cfg
        self.prev_hr: float | None = None

    def reset(self) -> None:
        self.prev_hr = None

    def estimate(self, rgb: np.ndarray, fs: float = FS) -> float:
        max_jump = MAX_JUMP_BPM if self.cfg.jump_rule else None
        self.prev_hr = pick_hr(source_signal(rgb, self.cfg, fs), self.prev_hr, fs, max_jump)
        return self.prev_hr
